from admin_presenter import admin_menu
from client_presenter import client_menu
from lib import hr
from factory import *

while True:
    choice = input("""1 - admin
2 - client
q - quit
Enter option:""")
    if choice == "1":
        admin_menu()
    if choice == "2":
        client_menu()
    if choice == "q":
        break
